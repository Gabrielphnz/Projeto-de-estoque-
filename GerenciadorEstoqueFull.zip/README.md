# GerenciadorEstoque (completo)

App Android em Kotlin (Compose + Room).

## Melhorias incluídas
- Exportar CSV via SAF
- Gerar PDF de relatórios
- Tela de importação CSV com preview
- codemagic.yaml incluso

## Como usar no Codemagic
1. Publique esta pasta no GitHub.
2. Vá em https://codemagic.io e conecte seu repositório.
3. O build roda e gera `app-debug.apk`.
4. Baixe o APK no painel ou receba por e-mail.
